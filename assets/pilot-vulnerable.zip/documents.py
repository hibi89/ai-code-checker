from pathlib import Path

DOCUMENT_ROOT = Path("/srv/portal/documents")

def read_document(filename: str) -> str:
    # filename comes from a requester-controlled HTTP query parameter.
    return (DOCUMENT_ROOT / filename).read_text(encoding="utf-8")
