from typing import Any

# Product rule: each invoice belongs to one authenticated user.
def get_invoice(db: Any, invoice_id: str, authenticated_user_id: int):
    # invoice_id is supplied by the requester.
    return db.fetch_one(
        "SELECT id, owner_id, total FROM invoices WHERE id = ?",
        (invoice_id,),
    )
