from pathlib import Path

DOCUMENT_ROOT = Path("/srv/portal/documents")

def read_document(filename: str) -> str:
    root = DOCUMENT_ROOT.resolve()
    candidate = (root / filename).resolve()
    if candidate == root or root not in candidate.parents:
        raise ValueError("Document path is outside the document directory")
    return candidate.read_text(encoding="utf-8")
