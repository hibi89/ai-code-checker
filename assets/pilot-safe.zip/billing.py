from typing import Any

# Product rule: each invoice belongs to one authenticated user.
def get_invoice(db: Any, invoice_id: str, authenticated_user_id: int):
    invoice = db.fetch_one(
        "SELECT id, owner_id, total FROM invoices WHERE id = ?",
        (invoice_id,),
    )
    if invoice is None:
        return None
    if invoice["owner_id"] != authenticated_user_id:
        raise PermissionError("Invoice belongs to another user")
    return invoice
